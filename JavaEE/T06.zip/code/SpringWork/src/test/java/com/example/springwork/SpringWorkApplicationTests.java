package com.example.springwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWorkApplicationTests {

    @Test
    void contextLoads() {
    }

}
