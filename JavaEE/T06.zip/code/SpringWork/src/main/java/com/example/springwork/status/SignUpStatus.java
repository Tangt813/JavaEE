package com.example.springwork.status;

/**
 * @ClassName: SignUpStatus
 * @Description: TODO
 * @Author: Tangt
 * @Date: 2021/12/11 15:07
 * @Version: v1.0
 */
public enum SignUpStatus {
    Email_Existed,//400
    Successful//200
}
